'use strict';

const intents = (intent) => {
  const mappedIntent = mapper[intent];
  if (mappedIntent) { return mappedIntent; } else { return undefined; }
};

const mapper = {
  'Default Welcome Intent': require('./intents/welcome'),
  'Send Money': require('./intents/sendmoney'),
  'Change Contact': require('./intents/accountNumber'),
  'Check Bal': require('./intents/checkbal'),
  'Acc Number': require('./intents/checkbalAccno'),
  'Capture Pin Value': require('./intents/capture-pin'),
  'Capture Phone Number': require('./intents/capture-phone-number'),
  'Check Bal Confirm Accno':require('./intents/checkbalAccno'),
  'Checkbal Confirm Acc No':require('./intents/balance'),
  'Thankyou':require('./intents/thankyou'),
  'Bye':require('./intents/bye'),
  'Send Money Acc No':require('./intents/senderAccno'),
  'Transfer to Acc No':require('./intents/transferAccno'),
  'Transfer amount':require('./intents/tranferAmt'),
  'Confirm money':require('./intents/transferdone'),
  'Change Contact':require('./intents/contact'),
  'Change Contact Acc no':require('./intents/changecontact'),
  'Mobile Number':require('./intents/updatecontact'),
  'Create New Account':require('./intents/newacc'),
  'Name':require('./intents/name'),
  'Name contact details':require('./intents/newaccphoneno'),
  'Address':require('./intents/aadhar'),
  'Aadhar number':require('./intents/confirmAadhar')
};

module.exports = intents;
