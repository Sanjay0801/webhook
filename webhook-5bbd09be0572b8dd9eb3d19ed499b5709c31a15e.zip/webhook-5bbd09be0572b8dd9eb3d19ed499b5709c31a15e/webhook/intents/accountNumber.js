'use strict';
const { getCtxParamValue } = require('../../helper/context');
const { setResponse } = require('../../helper/set-response');

const accno = (df) => {
  const globalParams = getCtxParamValue(df,'ALL_PARAMS');
  setResponse(df, 'accountNumber');
  df.setOutputContext('global-parameters',99,globalParams)
};



module.exports = accno;
