'use strict';
const { setResponse } = require('../../helper/set-response');
const { getCtxParamValue } = require('../../helper/context');

const updatecon = (df) => {
  const globalParams = getCtxParamValue(df,'ALL_PARAMS');
  const changePhoneno = globalParams.changePhoneno;
  
 // const pin = globalParams.number;
 
  setResponse(df, 'newphoneno', {'changePhoneno':changePhoneno});
  // setResponse(df, 'capturePin', {'pin':pin});
  df.setOutputContext('global-parameters',99,globalParams)
};

module.exports = updatecon;
