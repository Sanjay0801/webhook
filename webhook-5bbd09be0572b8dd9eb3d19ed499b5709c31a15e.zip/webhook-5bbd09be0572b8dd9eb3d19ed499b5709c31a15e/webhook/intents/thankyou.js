'use strict';
const { getCtxParamValue } = require('../../helper/context');
const { setResponse } = require('../../helper/set-response');

const ty = (df) => {
  const globalParams = getCtxParamValue(df,'ALL_PARAMS');
  setResponse(df, 'thanks');
  df.setOutputContext('global-parameters',99,globalParams)
};



module.exports = ty;
