'use strict';
const { setResponse } = require('../../helper/set-response');
const { getCtxParamValue } = require('../../helper/context');

const balcheck = (df) => {
  const globalParams = getCtxParamValue(df,'ALL_PARAMS');
  const checkBalAccno = globalParams.checkBalAccno;
  
 // const pin = globalParams.number;
 console.log("hey world hw r u?---asdsajalkll,n"+checkBalAccno);
  setResponse(df, 'checkbalAccno', {'checkBalAccno':checkBalAccno});
  // setResponse(df, 'capturePin', {'pin':pin});
  df.setOutputContext('global-parameters',99,globalParams)
};

module.exports = balcheck;
