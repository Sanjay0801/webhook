'use strict';
const { setResponse } = require('../../helper/set-response');
const { getCtxParamValue } = require('../../helper/context');

const transferacc = (df) => {
  const globalParams = getCtxParamValue(df,'ALL_PARAMS');
  const transferAccno = globalParams.transferAccno;
  
 // const pin = globalParams.number;
 
  setResponse(df, 'tranferaccno', {'transferAccno':transferAccno});
  // setResponse(df, 'capturePin', {'pin':pin});
  df.setOutputContext('global-parameters',99,globalParams)
};

module.exports = transferacc;
