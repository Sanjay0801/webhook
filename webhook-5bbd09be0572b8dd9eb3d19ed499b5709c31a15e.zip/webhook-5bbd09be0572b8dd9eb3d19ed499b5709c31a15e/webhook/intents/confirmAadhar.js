'use strict';
const { setResponse } = require('../../helper/set-response');
const { getCtxParamValue } = require('../../helper/context');

const confirmaad = (df) => {
  const globalParams = getCtxParamValue(df,'ALL_PARAMS');
  const aadharNumber = globalParams.aadharNumber;
  
  //const pin = globalParams.number;

  setResponse(df, 'aadharconfirm', {'aadharNumber':aadharNumber});
  // setResponse(df, 'capturePin', {'pin':pin});
  df.setOutputContext('global-parameters',99,globalParams)
};

module.exports = confirmaad;
