'use strict';
const { setResponse } = require('../../helper/set-response');
const { getCtxParamValue } = require('../../helper/context');

const tamt = (df) => {
  const globalParams = getCtxParamValue(df,'ALL_PARAMS');
  const transferAmtno = globalParams.transferAmtno;
  
 // const pin = globalParams.number;
 
  setResponse(df, 'confirmamt', {'transferAmtno':transferAmtno});
  // setResponse(df, 'capturePin', {'pin':pin});
  df.setOutputContext('global-parameters',99,globalParams)
};

module.exports = tamt;
