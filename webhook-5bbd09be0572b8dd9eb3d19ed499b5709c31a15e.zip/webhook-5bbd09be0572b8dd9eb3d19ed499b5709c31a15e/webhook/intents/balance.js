'use strict';
const { getCtxParamValue } = require('../../helper/context');
const { setResponse } = require('../../helper/set-response');

const bal = (df) => {
  const globalParams = getCtxParamValue(df,'ALL_PARAMS');
  setResponse(df, 'balance');
  df.setOutputContext('global-parameters',99,globalParams)
};



module.exports = bal;
