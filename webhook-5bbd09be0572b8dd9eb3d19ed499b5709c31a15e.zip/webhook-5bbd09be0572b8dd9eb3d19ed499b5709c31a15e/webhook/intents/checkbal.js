'use strict';
const { getCtxParamValue } = require('../../helper/context');
const { setResponse } = require('../../helper/set-response');

const checkbalance = (df) => {
  const globalParams = getCtxParamValue(df,'ALL_PARAMS');
  setResponse(df, 'checkbal');
  df.setOutputContext('global-parameters',99,globalParams)
};



module.exports = checkbalance;
