"use strict";

const config = {
    platformSupport: [
        "ACTIONS_ON_GOOGLE",
        "FACEBOOK_MESSENGER",
        "TELEPHONY",
	"TEXT"
    ]
}

module.exports = config;
