'use strict';

module.exports = {
  greetings: [`Hello, Welcome sanjay `],

  sendmoney:["yes definetly.  Could you please tell me your account number? "],

  senderaccno:["to which acc no should i transfer"],

  tranferaccno:['specify amount to be transfered'],

  

  confirmamt:['confirm <%= transferAmtno%> to be transfered'],

  transferdone:[ 'transfered'],

  contact:['sure! what is your acc no'],

  contactaccno:['tell me new phone number'],

  newphoneno:['updated'],

  accountNumber:["could you please tell me your account number"],

  checkbal:["what is your acc number"],

  checkbalAccno:['Is <%= checkBalAccno%>! your account number correct'],

  balance:["balance is 10,000"],

  thanks:["you are welcome. i can assist you if u need more help."],

  bye:["byeeeeee from bot"],

  newacc:['whatz your full name'],

  newaccphone:['enter your address'],

  aadhar:['enter aadhar details'],

  aadharconfirm:["confirm details"],

  name:['<%= personName%> tell me your contact details'],

  capturePhoneNumber: ['<%= phoneNumber%>!'],

  capturePin: ['<%= pin %>.']

  


};
